{
    apiKey: "AIzaSyBVmFA1iK5MSKLIhf3ACo6E0meUeRbPCgs";
    authDomain: "medicalsuite-99e48.firebaseapp.com";
    projectId: "medicalsuite-99e48";
    storageBucket: "medicalsuite-99e48.appspot.com";
    messagingSenderId: "679686285511";
    appId: "1:679686285511:web:be7e727760a15a61a9f6e2"
}